-- phpMyAdmin SQL Dump
-- version 3.3.9.2
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2013 年 03 月 17 日 12:37
-- 服务器版本: 5.1.41
-- PHP 版本: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `xinhuastu`
--
CREATE DATABASE `xinhuastu` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `xinhuastu`;

-- --------------------------------------------------------

--
-- 表的结构 `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `admin`
--


-- --------------------------------------------------------

--
-- 表的结构 `attendance`
--

CREATE TABLE IF NOT EXISTS `attendance` (
  `attid` int(11) NOT NULL AUTO_INCREMENT,
  `classid` int(11) NOT NULL,
  `addtime` int(11) NOT NULL,
  `NumP` int(11) NOT NULL,
  `content` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `whodo` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`attid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- 转存表中的数据 `attendance`
--


-- --------------------------------------------------------

--
-- 表的结构 `book`
--

CREATE TABLE IF NOT EXISTS `book` (
  `bookid` int(11) NOT NULL AUTO_INCREMENT,
  `bookname` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `whodo` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`bookid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- 转存表中的数据 `book`
--

INSERT INTO `book` (`bookid`, `bookname`, `whodo`) VALUES
(1, '计算机基础', '1'),
(2, '网络基础', '1'),
(3, 'photoshop', '1'),
(4, '3D max', '1'),
(5, 'CAD', '1'),
(6, '网页设计', '1'),
(7, 'CorelDRAW', '1'),
(8, 'office', '1');

-- --------------------------------------------------------

--
-- 表的结构 `certificate`
--

CREATE TABLE IF NOT EXISTS `certificate` (
  `cerid` int(11) NOT NULL AUTO_INCREMENT,
  `cername` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`cerid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- 转存表中的数据 `certificate`
--


-- --------------------------------------------------------

--
-- 表的结构 `class`
--

CREATE TABLE IF NOT EXISTS `class` (
  `classid` int(11) NOT NULL AUTO_INCREMENT,
  `classname` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `proid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `addtime` varchar(11) NOT NULL,
  `outtime` varchar(11) NOT NULL,
  `state` int(11) NOT NULL,
  `whodo` int(11) NOT NULL,
  PRIMARY KEY (`classid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- 转存表中的数据 `class`
--

INSERT INTO `class` (`classid`, `classname`, `proid`, `userid`, `addtime`, `outtime`, `state`, `whodo`) VALUES
(1, 'tc1102', 1, 1, '2013-03-04', '', 1, 0),
(2, 'tc1104', 1, 1, '2013-03-04', '', 1, 0),
(4, 'tc1301    ', 4, 3, '2013-03-04 ', '    ', 1, 0),
(5, 'tc1001  ', 4, 3, '2013-03-04 ', '  ', 0, 0),
(6, 'ce1105', 4, 1, '2013-03-04', '', 0, 0),
(7, 'tc1208', 5, 1, '2013-03-05', '', 0, 0),
(8, 'tc0904', 4, 3, '2013-03-05', '', 0, 0),
(9, 'ce0213', 3, 3, '1362478832', '', 0, 1),
(10, 'tc0320', 4, 3, '1362483490', '1362488974', 1, 1),
(11, 'TC1102艺术大专', 1, 4, '1304208000', '', 0, 1);

-- --------------------------------------------------------

--
-- 表的结构 `grade`
--

CREATE TABLE IF NOT EXISTS `grade` (
  `gradeid` int(11) NOT NULL AUTO_INCREMENT,
  `stuid` int(11) DEFAULT NULL,
  `bookid` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `userid` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `mark` float NOT NULL,
  `whodo` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `addtime` int(11) NOT NULL,
  PRIMARY KEY (`gradeid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- 转存表中的数据 `grade`
--


-- --------------------------------------------------------

--
-- 表的结构 `pegrade`
--

CREATE TABLE IF NOT EXISTS `pegrade` (
  `pegradeid` int(11) NOT NULL AUTO_INCREMENT,
  `stuid` int(11) NOT NULL,
  `bookid` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `userid` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `mark` float NOT NULL,
  `whodo` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `addtime` int(11) NOT NULL,
  PRIMARY KEY (`pegradeid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `pegrade`
--

INSERT INTO `pegrade` (`pegradeid`, `stuid`, `bookid`, `userid`, `mark`, `whodo`, `addtime`) VALUES
(1, 4, '1', '1', 90, '1', 2013),
(2, 2, '2', '1', 55, '1', 2013);

-- --------------------------------------------------------

--
-- 表的结构 `profession`
--

CREATE TABLE IF NOT EXISTS `profession` (
  `proid` int(11) NOT NULL AUTO_INCREMENT,
  `proname` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `probook` varchar(600) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `whodo` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`proid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- 转存表中的数据 `profession`
--

INSERT INTO `profession` (`proid`, `proname`, `probook`, `whodo`) VALUES
(1, '环境艺术表现', '', '1'),
(2, '国际网络工程师', '', '1'),
(3, '软件开发工程师', '', '1'),
(4, '计算机软件开发', '', '1'),
(5, 'e-boss高级商务师', '', '1');

-- --------------------------------------------------------

--
-- 表的结构 `result`
--

CREATE TABLE IF NOT EXISTS `result` (
  `reid` int(11) NOT NULL AUTO_INCREMENT,
  `stuid` int(11) NOT NULL,
  `cerid` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `userid` int(11) NOT NULL,
  `result` int(11) NOT NULL,
  `addtime` int(11) NOT NULL,
  `whodo` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `doip` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`reid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- 转存表中的数据 `result`
--


-- --------------------------------------------------------

--
-- 表的结构 `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `sid` int(11) NOT NULL AUTO_INCREMENT,
  `snum` varchar(100) DEFAULT NULL,
  `sname` varchar(50) NOT NULL,
  `sex` char(2) NOT NULL,
  `simg` varchar(500) CHARACTER SET gbk DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `tel` varchar(14) DEFAULT NULL,
  `htel` varchar(14) DEFAULT NULL,
  `qq` int(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `classid` int(11) DEFAULT NULL,
  `intime` int(11) DEFAULT NULL,
  `outtime` int(11) DEFAULT NULL,
  `adress` varchar(150) DEFAULT NULL,
  `state` int(11) DEFAULT NULL,
  `schoolid` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

--
-- 转存表中的数据 `student`
--

INSERT INTO `student` (`sid`, `snum`, `sname`, `sex`, `simg`, `age`, `tel`, `htel`, `qq`, `email`, `classid`, `intime`, `outtime`, `adress`, `state`, `schoolid`) VALUES
(1, 'xh111', '范继成', '1', '201303062058575103.jpg', 736041600, '15284426527', '15284426527', 1147942074, '1147942074@qq.com', 11, 1304640000, 1367366400, '云南 昆明', 0, ''),
(2, 'xh555', 'test', '2', '201303062058575103.jpg', 0, '', '', 0, '', 11, 1362574739, NULL, '', 2, NULL),
(4, 'sdsfd', 'ttt', '0', '201303062114412223.jpg', 1067385600, '234235', '32654654', 754754754, '4563453456346', 11, 1362528000, 0, '4363465', 1, ''),
(5, '', '1', '1', '201303062114412223.jpg', 0, '', '', 0, '', 11, 1362576182, NULL, '', 0, NULL),
(6, '', '2', '2', '201303062114412223.jpg', 0, '', '', 0, '', 11, 1362576187, NULL, '', 2, NULL),
(7, '', '3', '1', '201303062114412223.jpg', 0, '', '', 0, '', 11, 1362576195, NULL, '', 0, NULL),
(8, '', '4', '2', '201303062114412223.jpg', 0, '', '', 0, '', 11, 1362576201, NULL, '', 0, NULL),
(9, '', '5', '2', '201303062114412223.jpg', 0, '', '', 0, '', 11, 1362576206, NULL, '', 0, NULL),
(10, '', '6', '2', '201303062114412223.jpg', 0, '', '', 0, '', 11, 1362576212, NULL, '', 0, NULL),
(11, '', '7', '1', '201303062114412223.jpg', 0, '', '', 0, '', 11, 1362576217, NULL, '', 0, NULL),
(12, '', '8', '1', '201303062114412223.jpg', 0, '', '', 0, '', 11, 1362576223, NULL, '', 0, NULL),
(13, '', '9', '', '201303062114412223.jpg', 0, '', '', 0, '', 11, 1362576227, NULL, '', 0, NULL),
(14, '', '10', '', '201303062114412223.jpg', 0, '', '', 0, '', 11, 1362576233, NULL, '', 0, NULL),
(15, '', '11', '1', '201303062114412223.jpg', 0, '', '', 0, '', 11, 1362576238, NULL, '', 0, NULL),
(17, '', '13', '1', '201303062114412223.jpg', 0, '', '', 0, '', 11, 1362576249, NULL, '', NULL, NULL),
(18, '', '14', '1', '201303062114412223.jpg', 0, '', '', 0, '', 11, 1362576253, NULL, '', 0, NULL),
(19, '', '15', '1', '201303062114412223.jpg', 0, '', '', 0, '', 11, 1362576258, NULL, '', 0, NULL),
(20, '', '16', '1', '201303062114412223.jpg', 0, '', '', 0, '', 11, 1362576263, NULL, '', 2, NULL);

-- --------------------------------------------------------

--
-- 表的结构 `syllabus`
--

CREATE TABLE IF NOT EXISTS `syllabus` (
  `syid` int(11) NOT NULL AUTO_INCREMENT,
  `bookid` int(11) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `classid` int(11) NOT NULL,
  `addtime` int(11) DEFAULT NULL,
  `content` varchar(200) DEFAULT NULL,
  `state` int(11) DEFAULT NULL,
  `whodo` varchar(50) DEFAULT NULL,
  `whodo2` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`syid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `syllabus`
--

INSERT INTO `syllabus` (`syid`, `bookid`, `userid`, `classid`, `addtime`, `content`, `state`, `whodo`, `whodo2`) VALUES
(1, 1, 1, 11, 2013, NULL, 3, '1', '1'),
(2, 2, 1, 5, 2013, '65', 3, '1', '1');

-- --------------------------------------------------------

--
-- 表的结构 `user_group`
--

CREATE TABLE IF NOT EXISTS `user_group` (
  `groupid` int(11) NOT NULL AUTO_INCREMENT,
  `groupname` varchar(50) DEFAULT NULL,
  `douser` tinyint(1) DEFAULT '0',
  `doi` tinyint(1) DEFAULT '0',
  `dotextual` tinyint(1) DEFAULT '0',
  `doexam` tinyint(1) DEFAULT '0',
  `dotextl` tinyint(1) DEFAULT '0',
  `doeducational` tinyint(1) DEFAULT '0',
  `dobook` tinyint(1) DEFAULT '0',
  `domajor` tinyint(1) DEFAULT '0',
  `docourse` tinyint(1) DEFAULT '0',
  `dostmanage` tinyint(1) DEFAULT '0',
  `doclteacher` tinyint(1) DEFAULT '0',
  `doclass` tinyint(1) DEFAULT '0',
  `dostudent` tinyint(1) DEFAULT '0',
  `domentor` tinyint(1) DEFAULT '0',
  `doteacher` tinyint(1) DEFAULT '0',
  `doproscenium` tinyint(1) DEFAULT '0',
  `dolook` tinyint(1) DEFAULT '0',
  `dolookexam` tinyint(1) DEFAULT '0',
  `dolooktextual` tinyint(1) DEFAULT '0',
  `dolookcourse` tinyint(1) DEFAULT '0',
  `dolookstudent` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`groupid`)
) ENGINE=InnoDB  DEFAULT CHARSET=gbk AUTO_INCREMENT=14 ;

--
-- 转存表中的数据 `user_group`
--

INSERT INTO `user_group` (`groupid`, `groupname`, `douser`, `doi`, `dotextual`, `doexam`, `dotextl`, `doeducational`, `dobook`, `domajor`, `docourse`, `dostmanage`, `doclteacher`, `doclass`, `dostudent`, `domentor`, `doteacher`, `doproscenium`, `dolook`, `dolookexam`, `dolooktextual`, `dolookcourse`, `dolookstudent`) VALUES
(1, '超级管理员', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1),
(11, '管理员', 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(12, '测试用的', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1),
(13, '测试啊', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- 表的结构 `userinfo`
--

CREATE TABLE IF NOT EXISTS `userinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(200) NOT NULL,
  `userpwd` varchar(32) NOT NULL,
  `truename` varchar(30) DEFAULT NULL,
  `adddate` int(11) DEFAULT NULL,
  `telephone` int(12) DEFAULT NULL,
  `oicq` varchar(14) DEFAULT NULL,
  `msn` varchar(32) DEFAULT NULL,
  `lasttime` int(11) DEFAULT NULL,
  `email` varchar(120) DEFAULT NULL,
  `checked` tinyint(1) DEFAULT NULL,
  `groupid` smallint(6) DEFAULT NULL,
  `isclass` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=gbk AUTO_INCREMENT=5 ;

--
-- 转存表中的数据 `userinfo`
--

INSERT INTO `userinfo` (`id`, `username`, `userpwd`, `truename`, `adddate`, `telephone`, `oicq`, `msn`, `lasttime`, `email`, `checked`, `groupid`, `isclass`) VALUES
(1, 'admin', 'e10adc3949ba59abbe56e057f20f883e', '王飞', NULL, NULL, '', '', 1363522862, '', 0, 1, 1),
(2, 'test', 'e10adc3949ba59abbe56e057f20f883e', '飞天', NULL, NULL, NULL, NULL, 1362297450, NULL, 0, 13, 1),
(3, 'ad', 'e10adc3949ba59abbe56e057f20f883e', '张三', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1),
(4, 'wjh', 'e10adc3949ba59abbe56e057f20f883e', '王建辉', NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 1);
